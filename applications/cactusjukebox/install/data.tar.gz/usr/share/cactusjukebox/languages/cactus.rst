
# hash value = 363524
mainform.rsquit='Quit'


# hash value = 315429
mainform.rsfile='File'


# hash value = 161792334
mainform.rsopenfile='Open File...'


# hash value = 7301310
mainform.rsopendirector='Open Directory...'


# hash value = 202542537
mainform.rsplayeronly='Player only'


# hash value = 125478094
mainform.rschooseskin='Choose Skin...'


# hash value = 1551550
mainform.rssettings='Settings...'


# hash value = 49907913
mainform.rslibrary='Library'


# hash value = 44909033
mainform.rsnewlibrary='New library'


# hash value = 130875113
mainform.rsloadlibrary='Load library'


# hash value = 123817961
mainform.rssavelibrary='Save library'


# hash value = 211385423
mainform.rslibraryinfo='Library info'


# hash value = 95366382
mainform.rsmanagelibrar='Manage library...'


# hash value = 43005396
mainform.rsplaylist='Playlist'


# hash value = 357001
mainform.rsplay='Play'


# hash value = 347380
mainform.rsnext='Next'


# hash value = 147653555
mainform.rsprevious='Previous'


# hash value = 347301
mainform.rsmute='Mute'


# hash value = 31021028
mainform.rsloadplaylist='Load playlist'


# hash value = 184838116
mainform.rssaveplaylist='Save playlist'


# hash value = 55283170
mainform.rsmobileplayer='Mobile player'


# hash value = 3699060
mainform.rsclearplaylist='Clear Playlist'


# hash value = 104570196
mainform.rsrandomplaylist='Random Playlist'


# hash value = 181205379
mainform.rsdevices='Devices'


# hash value = 154945599
mainform.rsdeviceinfo='Device info'


# hash value = 122361794
mainform.rsscanplayer='Scan player'


# hash value = 372803
mainform.rssync='Sync'


# hash value = 63977346
mainform.rsclearplayer='Clear player'


# hash value = 101438686
mainform.rsundoselectio='Undo selection'


# hash value = 196088052
mainform.rsaudiocd='Audio CD'


# hash value = 208368718
mainform.rsripencode='Rip / Encode...'


# hash value = 322608
mainform.rshelp='Help'


# hash value = 158102910
mainform.rsabout='About...'


# hash value = 95929486
mainform.rsmanual='Manual...'


# hash value = 4860802
mainform.rsclear='Clear'


# hash value = 94079128
mainform.rssearch='Search'


# hash value = 4729277
mainform.rsalbum='Album'


# hash value = 2901221
mainform.rsfilename='Filename'


# hash value = 76132516
mainform.rsartist='Artist'


# hash value = 5966629
mainform.rstitle='Title'


# hash value = 92818269
mainform.rsrandom='Random'


# hash value = 249721124
mainform.rsnotconnected='Device not Connected'


# hash value = 1339
mainform.rsok='OK'


# hash value = 86789800
mainform.rslenght='Length'


# hash value = 5998491
mainform.rstrack='Track'


# hash value = 201018883
cdrip.rsencodetomp3='Encode to mp3'


# hash value = 162657090
cdrip.rsquerrycddb='Query CDDB'


# hash value = 341364
cdrip.rsload='Load'


# hash value = 4983716
cdrip.rseject='Eject'


# hash value = 5941396
cdrip.rsstart='Start'


# hash value = 296859
cdrip.rsback='Back'


# hash value = 241751763
cdrip.rssetid3tag='Write ID3-Tags'


# hash value = 117777587
cdrip.rscrsubfolders='Create artist subfolders'


# hash value = 153779989
cdrip.rsoutfilenamin='Outfile naming scheme'


# hash value = 38156832
settings.rsautoloadlast='Load last library at startup'


# hash value = 38301824
settings.rsscanfornewfi='Scan for new files in background  on startup'


# hash value = 139375349
settings.rslanguage='Language'


# hash value = 149648693
settings.rsguesstagfrom='Guess tag from filename'


# hash value = 96010723
settings.rsmovetosectio='Move to section %sUnknown%s'


# hash value = 123192501
settings.rsid3type='ID3 type'


# hash value = 258982169
settings.rsid3v1priorit='ID3v1 Priority'


# hash value = 258986265
settings.rsid3v2priorit='ID3v2 Priority'


# hash value = 231000124
settings.rsgeneral='General'


# hash value = 13971428
settings.rspathtomp3pla='Path to mp3player mountpoint'


# hash value = 190127860
settings.rscreatesubfol='Create subfolders on upload'


# hash value = 5586808
settings.rspathstoaddit='Paths to additional application needed for Cactu'+
's Jukebox'


# hash value = 215359881
settings.rscdda2wavtool='Cdda2wav (tool to rip CDs)'


# hash value = 366789
settings.rssave='Save'


# hash value = 77089212
settings.rscancel='Cancel'


# hash value = 16108981
settings.rsmobiledevice='Mobile Device'


# hash value = 5671667
settings.rspaths='Paths'


# hash value = 84600569
settings.rslameneededto='lame (needed to encode mp3 files)'


# hash value = 248584517
settings.rsenablekdeser='Enable KDE Service Menu'


# hash value = 31918036
settings.rsaudiooutput='Audio Output'


# hash value = 226111204
settings.rsdownloadalbu='Download album cover image from internet'


# hash value = 67326565
settings.rsclearcache='Clear Cache'


# hash value = 166301700
settings.rsautomaticlys='Automaticly start playing first song in playlist'+


# hash value = 43962272
settings.rsloadlastplay='Load last playlist on startup'


# hash value = 141599956
settings.rsalwaysstartp='Always start playing first song in empty playlis'+
't'


# hash value = 18931188
settings.rsstopplayback='Stop playback when playlist is cleared'


# hash value = 174068981
settings.rssortalbumsby='Sort albums by track instead of title'


# hash value = 54722019
settings.rsenableplugin='Enable plugins'

